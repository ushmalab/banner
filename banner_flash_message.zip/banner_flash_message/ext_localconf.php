<?php

defined('TYPO3') or die('Access denied.');

// Add default RTE configuration
$GLOBALS['TYPO3_CONF_VARS']['RTE']['Presets']['banner_flash_message'] = 'EXT:banner_flash_message/Configuration/RTE/Default.yaml';

